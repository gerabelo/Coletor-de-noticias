<?php
        header('Content-Type: text/html; charset=iso-8859-1');
        echo("<!doctype html><html><head><meta charset=\"utf-8\"><title></title></head><body><p><h1>news crawler</h1></p>");
        
        echo("<p><table><tr>");
        echo("<td><a href=\"modabysource.php\">moda</a></td>");
        echo("<td>&nbsp;</td>");
        echo("<td>sources</td>");
        echo("<td>&nbsp;</td>");
        echo("<td><a href=\"whitelist.php\">keywords</a></td>");
        echo("<td>&nbsp;</td>");        
        echo("<td><a href=\"blacklist.php\">ignoring</a></td>");
        echo("<td>&nbsp;</td>");        
        echo("<td><a href=\"newslist.php\">news</a></td>");
        echo("</tr></table></p>");


        
        $conexao = mysqli_connect("localhost","root","123456","newscrawler");
        if(!$conexao){
                echo("<p>Connection to content server failed.</p>");
                exit();
        }

        echo("<table><tr><td><b>ID</b></td><td><b>sources</b></td></tr>");
        

        $resultado = mysqli_query($conexao,"SELECT * FROM sources");

        while ($linha = mysqli_fetch_array($resultado)) {        
                echo("<tr><td>");
                echo($linha['id']);
                echo("</td><td><a href=\"");
                echo($linha['url']);
                echo("\">");
                echo($linha['url']);
                echo("</a></td></tr>");

        }
        echo("</table></body>");
        mysqli_free_result($resultado);
        mysqli_close($conexao);

?>

