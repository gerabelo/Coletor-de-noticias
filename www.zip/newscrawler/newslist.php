<?php

/*
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>news crawler</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="jquery-1.12.4.js"></script>
  <script src="jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#accordion" ).accordion();
  } );
  </script>
</head>
<body>


        header('Content-Type: text/html; charset=iso-8859-1');
        
        echo("<p><table><tr>");
        echo("<td><a href=\"sourceslist.php\">sources</a></td>");
        echo("<td>&nbsp;</td>");
        echo("<td><a href=\"whitelist.php\">keywords</a></td>");
        echo("<td>&nbsp;</td>");        
        echo("<td><a href=\"blacklist.php\">ignoring</a></td>");
        echo("<td>&nbsp;</td>");        
        echo("<td>news</td>");
        echo("</tr></table></p><div id=\"accordion\">");

        $conexao = mysqli_connect("localhost","root","123456","webbot");
        if(!$conexao){
                echo("<p>Connection to content server failed.</p>");
                exit();
        }

        $resultado = mysqli_query($conexao,"SELECT dateCreate,value,url,text FROM news ORDER BY value DESC");
        $count = 1;
        
        while ($linha = mysqli_fetch_array($resultado)) {
                echo ("<h3>".$count.". ".$linha['text']."</h3><div><p>");
                echo ("</td><td><a href=\"".$linha['url']."\">".$linha['url']."</a>");
                echo ("<br>");
                echo ($linha['dateCreate']." [+".$linha['value']."]");                
                echo ("</p></div>");
                $count++;
        }
        mysqli_free_result($resultado);
        mysqli_close($conexao);
        
        
        */
        
        header('Content-Type: text/html; charset=iso-8859-1');
        echo("<!doctype html><html><head><meta charset=\"utf-8\"><title></title></head><body><p><h1>news crawler</h1></p>");
                
        //var_dump($_POST['search']);
        $search = $_GET["search"];
        $source = $_GET["source"];
        
        $conexao = mysqli_connect("localhost","root","123456","newscrawler");

        if(!$conexao){
                echo("<p>Connection to content server failed.</p>");
                exit();
        }

        $data = date("Y/m/d"); 

        $query = mysqli_query($conexao,"SELECT id,url FROM sources ORDER BY url");
        
        echo("<form>");
        echo("<select name=\"source\" style=\"max-width:320px;\">");
        echo("<option value=\"0\"> all </option>");
        //        echo("<option value=\"0\"> todos </option>");
                while($prod = mysqli_fetch_array($query)) {
                        echo("<option value=\"".$prod['id']."\">".$prod['url']."</option>");
                } 
        
        echo("</select><br>");
        echo("<input type=\"text\" value=\"$search\" name=\"search\"><input type=\"submit\" value=\"Search\">");
        echo("</form>"); 

        echo("<p><table><tr>");
        echo("<td><a href=\"sourceslist.php\">sources</a></td>");
        echo("<td>&nbsp;</td>");
        echo("<td><a href=\"whitelist.php\">keywords</a></td>");
        echo("<td>&nbsp;</td>");        
        echo("<td><a href=\"blacklist.php\">ignoring</a></td>");
        echo("<td>&nbsp;</td>");        
        echo("<td>news</td>");
        echo("</tr></table></p>");
        
        echo("<table><tr><td>#</td><td><b>kw</b></td><td width='180'><b>Date</b></td><td><b>News</b></td></tr>");
        
        $conexao2 = mysqli_connect("localhost","root","123456","newscrawler");

        if (isset($source) && $source > 0) {
                $resultado = mysqli_query($conexao2,"SELECT url,text,dateCreate,value FROM news WHERE text LIKE '%$search%' AND value > 0 AND sourceId=$source ORDER BY dateCreate DESC LIMIT 300");
        } else {
                $resultado = mysqli_query($conexao2,"SELECT url,text,dateCreate,value FROM news WHERE text LIKE '%$search%' AND value > 0 ORDER BY dateCreate DESC LIMIT 300");        
        }
        
        $count = 1;
        
        while ($linha = mysqli_fetch_array($resultado)) {        
                echo("<tr><td>");
                echo($count++);
                echo("</td><td>");
                echo(" ".$linha['value']);
                echo("</td><td>");
                echo(" ".$linha['dateCreate']);
                echo("</td><td>");
                echo("<a href=\"".$linha['url']."\">".$linha['text']."</a>");
                echo("</td></tr>");
        }
        echo("</table></body>");
        mysqli_free_result($resultado);
        mysqli_close($conexao);


        echo("</body>");
        echo("</html>");

?>
        
        
        

