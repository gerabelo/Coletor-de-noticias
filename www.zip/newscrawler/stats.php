<?php
        header('Content-Type: text/html; charset=iso-8859-1');
        echo("<!doctype html><html><head><meta charset=\"utf-8\"><title></title></head><body><p><h1>news crawler</h1></p>");
        
        echo("<p><table><tr>");
        echo("<td><a href=\"sourcelist.php\">news</a></td>");
        echo("<td>&nbsp;</td>");
        echo("<td><a href=\"whitelist.php\">keywords</a></td>");
        echo("<td>&nbsp;</td>");        
        echo("<td><a href=\"blacklist.php\">ignoring</a></td>");
        echo("<td>&nbsp;</td>");        
        echo("<td><a href=\"newslist.php\">news</a></td>");
        echo("</tr></table></p>");

        $data = date("Y/m/d"); 
        
        $conexao = mysqli_connect("localhost","root","123456","newscrawler");
        if(!$conexao){
                echo("<p>Connection to content server failed.</p>");
                exit();
        }

        echo("<table><tr><td width=\"100px\"><b>times</b></td><td width=\"150px\"><b>word</b></td></tr>");
        

        $resultado = mysqli_query($conexao,"SELECT counter,word FROM moda WHERE dateCreate = '$data' ORDER BY counter DESC");

        while ($linha = mysqli_fetch_array($resultado)) {        
                echo("<tr><td>");
                echo($linha['counter']);
                echo("</td><td>");
                echo($linha['word']);
                echo("</td></tr>");

        }
        echo("</table></body>");
        mysqli_free_result($resultado);
        mysqli_close($conexao);

?>

